#natesblog

Ok here we go. This is the starting point of the blog.

The current URL to this blog is at https://natesblog.markbase.xyz

Custom domains, CSS, and JS can be used if needed. But as a place to just get content out of the same place where I store ideas, this is a pretty decent starting point.